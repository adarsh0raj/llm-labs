### CODE

- The file `a2.ipynb` in the directory `code/` consists of code for all the three questions. 
- You need to run the cells in the notebook sequentially.

### Outputs

- Metrics Outputs are stored in `outputs` directory.

### Report

- For detailed report, please refer to `report.pdf` file.
